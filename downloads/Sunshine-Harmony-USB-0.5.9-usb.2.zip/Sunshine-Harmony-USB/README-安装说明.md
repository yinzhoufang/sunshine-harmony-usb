# Sunshine 基地版增强补丁 0.5.9+usb.2

功能：设备中心切换网络 / 鸿蒙 USB 模式；虚拟显示器页面手动开关虚拟屏。

要求：Sunshine 基地版、GUI 0.5.9 系列、默认安装目录 C:\Program Files\Sunshine。虚拟屏需要对应 VDD 驱动和兼容核心接口。

完整解压后运行“安装集成版.bat”，接受管理员授权。安装器会校验并备份面板。恢复时运行“恢复原版面板.bat”。安装补丁不会自动切换传输模式。

USB 串流另需 Python 3、华为官方 HDC、已签名安装的平板桥 App 和 Moonlight。这些安装器不在此包内。平板桥源码在项目仓库 pad/，需自行签名构建。平板后台冻结仍是已知限制，建议以分屏或悬浮窗保持桥可见。

本包不含 DHCP 服务、不新增开机自启动。模式切换由面板维护端口，勿手工改端口。

完整说明：https://github.com/yinzhoufang/sunshine-harmony-usb
